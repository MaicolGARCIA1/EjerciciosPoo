package Poo2;

public class Flecha {
	int longitud;
	String color;
	
	public Flecha() {
		longitud=18;
		color = "Negro";
	}
	public Flecha(int longitud, String color) {
		this.longitud= longitud;
		this.color=color;
	}
	public void imprimir() {
		System.out.println();
	}
	public void construirFlecha() {
		for (int i = 0; i < longitud; i++) {
			imprime("_");
			
		}
	}
	private void imprime(String simbolo) {
		if (color.equals("Negro")) {
			System.out.println(simbolo);
		}else {
			System.err.println(simbolo);
		}
	}
}
